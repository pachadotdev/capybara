## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(capybara)

## ----verification1------------------------------------------------------------
felm(ltrade ~ bothin + onein + gsp + ldist + lrgdp + lrgdppc + regional +
  custrict + comlang + border + landl + island + lareap + comcol +
  curcol + colony + comctry | year, data = ross2004)

## ----table4b_models, cache = TRUE---------------------------------------------
fml <- ltrade ~ bothin + onein + gsp + ldist + lrgdp + lrgdppc + regional +
  custrict + comlang + border + landl + island + lareap + comcol +
  curcol + colony + comctry | year

# IID  (no cluster part in formula)
fit_iid <- felm(
  fml,
  data = ross2004, vcov = "iid"
)

# Heteroskedastic-robust (HC0)
fit_hetero <- felm(
  fml,
  data = ross2004, vcov = "hetero"
)

# One-way: cluster on country-pair (g,h)
fit_pairs <- felm(
  update(fml, . ~ . | . | pair),
  data = ross2004, vcov = "cluster"
)

# One-way: cluster on country 1 (g)
fit_ctry1 <- felm(
  update(fml, . ~ . | . | ctry1),
  data = ross2004, vcov = "cluster"
)

# One-way: cluster on country 2 (h)
fit_ctry2 <- felm(
  update(fml, . ~ . | . | ctry2),
  data = ross2004, vcov = "cluster"
)

# Two-way: cluster on (g) and (h) simultaneously
fit_2way <- felm(
  update(fml, . ~ . | . | ctry1 + ctry2),
  data = ross2004, vcov = "cluster"
)

# Dyadic-robust: Cameron-Miller (2014) sandwich with cross-dyad correlations
fit_dyadic <- felm(
  update(fml, . ~ . | . | ctry1 + ctry2),
  data = ross2004, vcov = "dyadic"
)

## ----table4b_display----------------------------------------------------------
summary_table(
  fit_iid, fit_hetero, fit_pairs, fit_ctry1, fit_ctry2, fit_2way, fit_dyadic,
  model_names = c("IID", "Hetero", "Pairs", "Country 1", "Country 2", "2-Way", "Dyadic")
)

