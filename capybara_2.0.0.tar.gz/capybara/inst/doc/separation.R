## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(capybara)

## ----example1-data------------------------------------------------------------
correia2019$example1
which(correia2019$example1$x2 - correia2019$example1$x1 != 0 & correia2019$example1$y == 0)

## ----example1-glm-------------------------------------------------------------
glm(
  y ~ x1 + x2 + x3 + x4,
  data = correia2019$example1,
  family = poisson()
)

## ----example1-fepoisson-------------------------------------------------------
fepoisson(
  y ~ x1 + x2 + x3 + x4,
  data = correia2019$example1
)

## ----example2-data------------------------------------------------------------
correia2019$example2
which(correia2019$example2$x2 - correia2019$example2$x1 > 0 & correia2019$example2$y == 0)

## ----example2-glm, warning=TRUE-----------------------------------------------
glm(
  y ~ x1 + x2 + x3 + x4,
  data = correia2019$example2,
  family = poisson()
)

## ----example2-fepoisson-------------------------------------------------------
fepoisson(
  y ~ x1 + x2 + x3 + x4,
  data = correia2019$example2
)

## ----fe1-data-----------------------------------------------------------------
correia2019$fe1

## ----fe1-glm------------------------------------------------------------------
glm(
  y ~ x1 + x2 + factor(i) + factor(j),
  data = correia2019$fe1,
  family = poisson()
)

## ----fe1-capybara-------------------------------------------------------------
fepoisson(
  y ~ x1 + x2 | i + j,
  data = correia2019$fe1
)

## ----fe1-capybara-2-----------------------------------------------------------
correia2019$fe1$pair <- paste0(correia2019$fe1$i, correia2019$fe1$j)

fepoisson(
  y ~ x1 + x2 | i + j | pair,
  data = correia2019$fe1
)

## ----fe-capybara-3------------------------------------------------------------
fepoisson(
  y ~ x1 + x2 | i + j,
  data = correia2019$fe1,
  control = list(check_separation = FALSE)
)

## ----fe-alpaca, eval = FALSE--------------------------------------------------
# alpaca::feglm(
#   y ~ x1 + x2 | i + j,
#   data = correia2019$fe1,
#   family = poisson()
# )

## ----fe-fixest, eval = FALSE--------------------------------------------------
# fixest::feglm(
#   y ~ x1 + x2 | i + j,
#   data = correia2019$fe1,
#   family = poisson()
# )

