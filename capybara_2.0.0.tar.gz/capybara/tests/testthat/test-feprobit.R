#' srr_stats (tests)
#' @srrstats {RE3.1} Validates consistency between `feprobit` and other established R models like `glm` with comparable families.
#' @srrstats {RE3.2} Compares coefficients produced by `feprobit` with those from base R models to validate similarity.
#' @srrstats {RE4.3} Ensures stable estimates when adding negligible noise to the data.
#' @srrstats {RE5.1} Validates proper output generation for the model summary and printing methods.
#' @srrstats {RE7.3} Confirms that estimated coefficients are within a reasonable variation threshold compared to baseline models.
#' @srrstats {G5.10} The CAPYBARA_EXTENDED_TESTS environment variable can be set to true to run extended tests.
#' @srrstats {G5.11} The extended tests do not require additional downloads.
#' @srrstats {G5.11a} As for G5.11., the extended tests do not require additional downloads.
#' @srrstats {G5.12} The extended tests verify that the algorithm fitting time is robust to noise. This has to be tested with a larger dataset to see that time(clean) <= time(noisy).
#' @noRd
NULL

test_that("feprobit is similar to base", {
  skip_on_cran()

  # K = 1

  mod <- feprobit(am ~ wt | cyl, mtcars, control = fit_control(return_fe = TRUE))

  mod_base <- glm(
    am ~ wt + as.factor(cyl),
    mtcars,
    family = binomial(link = "probit")
  )

  coef_dist_base <- coef(mod_base)[2]

  dist_variation <- unname(abs((coef(mod)[1] - coef_dist_base) / coef(mod)[1]))

  expect_equal(dist_variation, 0.0, tolerance = 1e-2)

  expect_output(print(mod))

  expect_visible(summary(mod))

  n <- unname(mod[["nobs"]]["nobs_full"])
  expect_equal(length(fitted(mod)), n)
  expect_equal(length(predict(mod)), n)
  expect_equal(length(coef(mod)), 1)

  smod <- summary(mod)

  expect_equal(length(coef(smod)[, 1]), 1)
  expect_output(summary_formula_(smod))
  expect_output(summary_family_(smod))
  expect_output(summary_estimates_(smod, 3))
  expect_output(summary_r2_(smod, 3))
  expect_output(summary_nobs_(smod))
  expect_output(summary_fisher_(smod))

  # K = 2

  mod <- feprobit(am ~ wt | cyl + gear, mtcars, control = fit_control(return_fe = TRUE))

  mod_base <- glm(
    am ~ wt + as.factor(cyl) + as.factor(gear),
    mtcars,
    family = binomial(link = "probit")
  )

  coef_dist_base <- coef(mod_base)[2]

  dist_variation <- abs((coef(mod)[1] - coef_dist_base) / coef(mod)[1])

  expect_lt(dist_variation, 0.05)

  # K = 3

  mod <- feprobit(am ~ wt | cyl + gear + carb, mtcars, control = fit_control(return_fe = TRUE))

  mod_base <- glm(
    am ~ wt + as.factor(cyl) + as.factor(gear) + as.factor(carb),
    mtcars,
    family = binomial(link = "probit")
  )

  coef_dist_base <- coef(mod_base)[2]

  dist_variation <- abs((coef(mod)[1] - coef_dist_base) / coef(mod)[1])

  expect_lt(dist_variation, 0.05)

  expect_equal(mod[["fitted_values"]], mod_base[["fitted.values"]], tolerance = 1e-2)

  pred_mod <- predict(mod, type = "response")
  pred_mod_base <- predict(mod_base, type = "response")

  pred_mod_link <- predict(mod, type = "link")
  pred_mod_base_link <- predict(mod_base, type = "link")

  expect_equal(pred_mod, pred_mod_base, tolerance = 1e-2)
  expect_equal(pred_mod_link, pred_mod_base_link, tolerance = 1e-2)

  pred_mod <- predict(mod, type = "response", newdata = mtcars[1:10, ])
  pred_mod_base <- predict(mod_base, type = "response", newdata = mtcars[1:10, ])

  pred_mod_link <- predict(mod, type = "link", newdata = mtcars[1:10, ])
  pred_mod_base_link <- predict(mod_base, type = "link", newdata = mtcars[1:10, ])

  expect_equal(unname(pred_mod), unname(pred_mod_base), tolerance = 1e-2)
  expect_equal(unname(pred_mod_link), unname(pred_mod_base_link), tolerance = 1e-2)
})

test_that("feprobit estimation is the same adding noise to the data", {
  set.seed(123)

  d <- mtcars[, c("am", "wt", "cyl")]
  d$wt2 <- d$wt + pmax(rnorm(nrow(d)), 0) * .Machine$double.eps

  m1 <- feprobit(am ~ wt | cyl, d)
  m2 <- feprobit(am ~ wt2 | cyl, d)

  expect_equal(unname(coef(m1)), unname(coef(m2)))
  expect_equal(m1$fixed.effects, m2$fixed.effects)
})

test_that("proportional regressors return NA coefficients", {
  set.seed(200100)
  d <- data.frame(
    y = rbinom(100, 1, 0.5),
    x1 = rnorm(100),
    f = factor(sample(1:2, 100, replace = TRUE))
  )
  d$x2 <- 2 * d$x1

  fit1 <- glm(y ~ x1 + x2 + as.factor(f), data = d, family = binomial(link = "probit"))
  fit2 <- feprobit(y ~ x1 + x2 | f, data = d)

  expect_equal(coef(fit2), coef(fit1)[2:3], tolerance = 1e-2)
  expect_equal(predict(fit2), predict(fit1, type = "response"), tolerance = 1e-2)
})

test_that("feprobit and feglm with probit() give the same results", {
  mod1 <- feprobit(am ~ wt | cyl, mtcars)
  mod2 <- feglm(am ~ wt | cyl, mtcars, family = probit())
  mod3 <- feglm(am ~ wt | cyl, mtcars, family = binomial(link = "probit"))

  expect_equal(coef(mod1), coef(mod2))
  expect_equal(coef(mod1), coef(mod3))
  expect_equal(fitted(mod1), fitted(mod2))
  expect_equal(fitted(mod1), fitted(mod3))
})

test_that("feprobit handles cluster standard errors", {
  mod <- feprobit(am ~ wt | cyl | gear, mtcars, vcov = "cluster")
  smod <- summary(mod)

  expect_equal(mod$vcov_type, "cluster")
  expect_true(all(is.finite(coef(smod)[, "Std. Error"])))
})

# Stammann centering ----

test_that("feprobit is similar to base (stammann centering)", {
  skip_on_cran()
  ctrl <- fit_control(centering = "stammann", return_fe = TRUE)

  # K = 1

  mod <- feprobit(am ~ wt | cyl, mtcars, control = ctrl)

  mod_base <- glm(
    am ~ wt + as.factor(cyl),
    mtcars,
    family = binomial(link = "probit")
  )

  dist_variation <- unname(abs(
    (coef(mod)[1] - coef(mod_base)[2]) / coef(mod)[1]
  ))

  expect_equal(dist_variation, 0.0, tolerance = 1e-2)

  n <- unname(mod[["nobs"]]["nobs_full"])
  expect_equal(length(fitted(mod)), n)
  expect_equal(length(predict(mod)), n)
  expect_equal(length(coef(mod)), 1)

  # K = 2

  mod <- feprobit(am ~ wt | cyl + gear, mtcars, control = ctrl)

  mod_base <- glm(
    am ~ wt + as.factor(cyl) + as.factor(gear),
    mtcars,
    family = binomial(link = "probit")
  )

  dist_variation <- abs((coef(mod)[1] - coef(mod_base)[2]) / coef(mod)[1])

  expect_lt(dist_variation, 0.05)

  # K = 3

  mod <- feprobit(am ~ wt | cyl + gear + carb, mtcars, control = ctrl)

  mod_base <- glm(
    am ~ wt + as.factor(cyl) + as.factor(gear) + as.factor(carb),
    mtcars,
    family = binomial(link = "probit")
  )

  dist_variation <- abs((coef(mod)[1] - coef(mod_base)[2]) / coef(mod)[1])

  expect_lt(dist_variation, 0.05)

  expect_equal(mod[["fitted_values"]], mod_base[["fitted.values"]], tolerance = 1e-2)

  pred_mod <- predict(mod, type = "response")
  pred_mod_base <- predict(mod_base, type = "response")
  expect_equal(pred_mod, pred_mod_base, tolerance = 1e-2)

  pred_mod <- predict(mod, type = "response", newdata = mtcars[1:10, ])
  pred_mod_base <- predict(mod_base, type = "response", newdata = mtcars[1:10, ])
  expect_equal(unname(pred_mod), unname(pred_mod_base), tolerance = 1e-2)
})

test_that("feprobit estimation is the same adding noise to the data (stammann centering)", {
  ctrl <- list(centering = "stammann")
  set.seed(123)
  d <- mtcars[, c("am", "wt", "cyl")]
  d$wt2 <- d$wt + pmax(rnorm(nrow(d)), 0) * .Machine$double.eps

  m1 <- feprobit(am ~ wt | cyl, d, control = ctrl)
  m2 <- feprobit(am ~ wt2 | cyl, d, control = ctrl)

  expect_equal(unname(coef(m1)), unname(coef(m2)))
  expect_equal(m1$fixed.effects, m2$fixed.effects)
})

test_that("proportional regressors return NA coefficients (stammann centering)", {
  ctrl <- list(centering = "stammann")
  set.seed(200100)
  d <- data.frame(
    y = rbinom(100, 1, 0.5),
    x1 = rnorm(100),
    f = factor(sample(1:2, 100, replace = TRUE))
  )
  d$x2 <- 2 * d$x1

  fit1 <- glm(y ~ x1 + x2 + as.factor(f), data = d, family = binomial(link = "probit"))
  fit2 <- feprobit(y ~ x1 + x2 | f, data = d, control = ctrl)

  expect_equal(coef(fit2), coef(fit1)[2:3], tolerance = 1e-2)
  expect_equal(predict(fit2), predict(fit1, type = "response"), tolerance = 1e-2)
})
